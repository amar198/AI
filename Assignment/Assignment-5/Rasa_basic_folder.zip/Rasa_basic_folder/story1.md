## Generated Story 8155604663805596755
* greet
    - utter_greet
* restaurant_search
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_location
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - utter_ask_budget
* restaurant_search{"budget": "around 400"}
    - slot{"budget": "medium"}
    - action_restaurant
    - utter_ask_email_id
* restaurant_search{"email": "abc.xyz@somemaildomain.com"}
    - slot{"email": "abc.xyz@somemaildomain.com"}
    - send_email
    - utter_goodbye
* greet
    - export

