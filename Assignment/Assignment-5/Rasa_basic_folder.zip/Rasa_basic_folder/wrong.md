## Generated Story -1895693560462953825
* greet
    - utter_greet
* restaurant_search
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_location
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - utter_ask_budget
* restaurant_search{"cuisine": "around 500"}
    - slot{"cuisine": "around 500"}
    - export

## Generated Story 2906254643129766339
* greet
    - utter_greet
* restaurant_search
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_location
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - utter_ask_budget
* restaurant_search{"cuisine": "low"}
    - slot{"cuisine": "low"}
    - export

## Generated Story -6562870770291450626
* greet
    - utter_greet
* restaurant_search
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_location
* restaurant_search{"location": "meerut"}
    - slot{"location": "meerut"}
    - utter_ask_budget
* restaurant_search{"budget": "low"}
    - slot{"budget": "low"}
    - action_restaurant
    - slot{"location": "meerut"}
    - utter_ask_email_id
* restaurant_search
    - export

## Generated Story -8185005680822483791
* greet
    - utter_greet
* restaurant_search{"location": "bikaner"}
    - slot{"location": "bikaner"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_budget
* restaurant_search
    - utter_ask_budget
* restaurant_search{"budget": "medium"}
    - slot{"budget": "medium"}
    - action_restaurant
    - utter_if_details_required_in_email
* restaurant_search{"email": "amar198@gmail.com"}
    - slot{"email": "amar198@gmail.com"}
    - export

