## Generated Story -5812142585465793893
* greet
    - utter_greet
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_budget
* restaurant_search{"budget": "high"}
    - slot{"budget": "high"}
    - action_restaurant
    - slot{"location": "mumbai"}
    - utter_if_details_required_in_email
* affirm
    - utter_ask_email_id
* restaurant_search{"email": "amar198@gmail.com"}
    - slot{"email": "amar198@gmail.com"}
    - email_check
    - slot{"email": "amar198@gmail.com"}
    - send_email
    - slot{"email": "amar198@gmail.com"}
    - utter_goodbye

