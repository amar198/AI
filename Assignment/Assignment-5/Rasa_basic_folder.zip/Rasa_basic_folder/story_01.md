## Generated Story -2130479913349036537
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - city_check
    - slot{"location": "mumbai"}
    - utter_ask_budget
* restaurant_search{"budget": ">700"}
    - slot{"budget": ">700"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_restaurant
    - slot{"email_response": "White Charcoal - The Empresa Hotel in The Empresa Hotel, Oberoi Complex, Off New Link Road, Andheri Lokhandwala, Andheri West has been rated 4.9\nKnotty Yard in 1st Floor, Above China Valley, Opposite Powai Hiranandani Bus Depot, Powai, Mumbai has been rated 4.9\nOn Toes in 1st Floor, New Chandra CHS, Above Skoda Showroom, Veera Desai Area, Mumbai has been rated 4.9\nTamasha in Ground Floor, Victoria House, E.B Marg, Lower Parel, Mumbai has been rated 4.8\nHitchki in 002, First International Financial Centre, G Block, Bandra Kurla Complex, Mumbai has been rated 4.8\nHitchki in 5, Transocean, Hiranandani Business Park, Lake Boulevard Road, Powai, Mumbai has been rated 4.8\nHITCHKI in Ground Floor, Viviana Mall, Eastern Express Highway, Near Jupiter Hospital, Majiwada, Thane West has been rated 4.8\nPalladium Social in Level 3, Palladium Mall, Senapati Bapat Marg, Lower Parel, Mumbai has been rated 4.8\nFebruary 30 in Shop 28, Ground Floor, Meera Co-Operative Housing Society Limited, Oshiwara Link Road, Oshiwara, Andheri West, Mumbai has been rated 4.8\nThe Studs Sports Bar & Grill in Shop 10 & 11, Sagar Pallazio, Near Sakinaka Junction, Andheri Kurla Road, Sakinaka, Mumbai has been rated 4.8\n"}
    - utter_if_details_required_in_email
* affirm
    - utter_ask_email_id
* restaurant_search{"email": "amar198@gmail.com"}
    - slot{"email": "amar198@gmail.com"}
    - email_check
    - slot{"email": "amar198@gmail.com"}
    - send_email
    - slot{"email": "amar198@gmail.com"}
    - utter_goodbye
    - export

## Generated Story 5804663930441786387
* greet
    - utter_greet
* restaurant_search
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - city_check
    - slot{"location": "bangalore"}
    - utter_ask_budget
* restaurant_search{"budget": ">700"}
    - slot{"budget": ">700"}
    - action_restaurant
    - slot{"email_response": "1. Biergarten in 4th B Cross, Koramangala 5th Block, Bangalore has been rated 4.9\n\n2. Byg Brewski Brewing Company in 22/123, Byrathi Village, Bidarahalli Hobli, Hennur, Bangalore has been rated 4.9\n\n3. TBC Sky Lounge in Astra Hotel, 2795, 27th Main, Sector 1, HSR, Bangalore has been rated 4.9\n\n4. Byg Brewski Brewing Company in Behind MK Retail, Sarjapur Road, Bangalore has been rated 4.9\n\n5. Asia Kitchen By Mainland China in 136, Ground Floor, 1st Cross, 5th Block, Jyoti Niwas College Road, Koramangala 5th Block, Bangalore has been rated 4.9\n\n6. The Globe Grub in 2nd Floor, Soul Space Paradigm, Above Bata Showroom, Outer Ring Road, Marathahalli, Bangalore has been rated 4.9\n\n7. AB's - Absolute Barbecues in 100 Feet Road, 1st Phase, Near Jayadeva Flyover, 2nd Stage, BTM, Bangalore has been rated 4.9\n\n8. Brew and Barbeque - A Microbrewery Pub in 36/4, Fourth Floor, Soul Space Arena, Outer Ring Road, Doddanekkundi Village, Marathahalli, Bangalore has been rated 4.8\n\n9. The Globe Grub in C K Emerald, Opposite Yes Bank, BTM Layout, Near Shoppers Stop Bannerghata Main Road, BTM, Bangalore has been rated 4.8\n\n10. Communiti in 67 & 68, Brigade Solitaire, Opposite To Advaith Hyundai, Residency Road, Bangalore has been rated 4.8\n\n"}
    - utter_if_details_required_in_email
* affirm
    - utter_ask_email_id
* restaurant_search{"email": "amar198@gmail.com"}
    - slot{"email": "amar198@gmail.com"}
    - email_check
    - slot{"email": "amar198@gmail.com"}
    - send_email
    - slot{"email": "amar198@gmail.com"}
    - utter_goodbye
    - export

## Generated Story 1349762936156178440
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_location
* restaurant_search{"location": "Chennai"}
    - slot{"location": "Chennai"}
    - city_check
    - slot{"location": "chennai"}
    - utter_ask_budget
* restaurant_search{"budget": ">700"}
    - slot{"budget": ">700"}
    - action_restaurant
    - slot{"email_response": "1. Coal Barbecues in Shop 17-18, Rajalakshmi Nagar, 7th Cross Street, 100 Feet Bypass Road, Velachery, Chennai has been rated 4.9\n\n2. Coal Barbecues in 40, 2nd Floor, Bazullah Road, T. Nagar, Chennai has been rated 4.9\n\n3. AB's - Absolute Barbecues in 45, GN Chetty Road, T. Nagar, Chennai has been rated 4.9\n\n4. AB's - Absolute Barbecues in 5th Floor, Vivira Mall, Navallur, Chennai has been rated 4.9\n\n5. Barbeque Nation in 39, 1st Floor, Bazullah Road, Star City Serviced Apartments, T. Nagar, Chennai has been rated 4.9\n\n6. Chili's American Grill & Bar in S-29, 2nd Floor, Phoneix Market City, 142, Velachery Main Road, Chennai has been rated 4.8\n\n7. Chili's American Grill & Bar in 49 & 50 L, Express Avenue Mall, White's Road, Royapettah, Chennai has been rated 4.8\n\n8. Barbeque Nation in 11, Ground Floor, Ramaniyam Isha, Block 1, Thuraipakkam, Chennai has been rated 4.8\n\n9. The Black Pearl in Plot 155, 292/132, Ground Floor, Rajiv Gandhi Salai, Old Mahabalipuram Road, Sholinganallur, Chennai has been rated 4.7\n\n10. Mainland China in 1st Floor, 142, Phoenix Market City, Velachery, Chennai has been rated 4.7\n\n"}
    - utter_if_details_required_in_email
* affirm
    - utter_ask_email_id
* restaurant_search{"email": "amar198@gmail.com"}
    - slot{"email": "amar198@gmail.com"}
    - email_check
    - slot{"email": "amar198@gmail.com"}
    - send_email
    - slot{"email": "amar198@gmail.com"}
    - utter_goodbye
    - export

