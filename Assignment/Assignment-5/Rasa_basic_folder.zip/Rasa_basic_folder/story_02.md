## Generated Story -6075779319831308807
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_location
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - utter_ask_budget
* restaurant_search{"budget": "300 and 700"}
    - slot{"budget": "medium"}
    - action_restaurant
    - slot{"location": "mumbai"}
    - utter_if_details_required_in_email
* affirm
    - utter_ask_email_id
* restaurant_search{"email": "mrunmayee.deshpande28@gmail.com"}
    - slot{"email": "mrunmayee.deshpande28@gmail.com"}
    - email_check
    - slot{"email": "mrunmayee.deshpande28@gmail.com"}
    - send_email
    - slot{"email": "mrunmayee.deshpande28@gmail.com"}
    - utter_goodbye
    - export

## Generated Story 8522477858809017235
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bengaluru"}
    - slot{"location": "bengaluru"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_budget
* restaurant_search{"budget": "medium"}
    - slot{"budget": "medium"}
    - action_restaurant
    - slot{"location": "bengaluru"}
    - utter_if_details_required_in_email
* affirm
    - utter_ask_email_id
* restaurant_search{"email": "amar198@gmail.com"}
    - slot{"email": "amar198@gmail.com"}
    - email_check
    - slot{"email": "amar198@gmail.com"}
    - send_email
    - slot{"email": "amar198@gmail.com"}
    - export

## Generated Story -2938769870370999074
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "pune"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "pune"}
    - city_check
    - slot{"location": "pune"}
    - utter_ask_budget
* restaurant_search{"budget": ">700"}
    - slot{"budget": ">700"}
    - action_restaurant
    - slot{"location": "pune"}
    - utter_if_details_required_in_email
* affirm
    - utter_ask_email_id
* restaurant_search{"email": "amar198@gmail.com"}
    - slot{"email": "amar198@gmail.com"}
    - email_check
    - slot{"email": "amar198@gmail.com"}
    - send_email
    - slot{"email": "amar198@gmail.com"}
    - utter_goodbye
    - export

